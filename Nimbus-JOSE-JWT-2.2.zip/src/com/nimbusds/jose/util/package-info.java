/**
 * Base64, Base64URL, compression and JSON utility classes.
 *
 * @author Vladimir Dzhuvinov
 * @version $version$ ($version-date$)
 */
package com.nimbusds.jose.util;
